#pragma once

#include <cmath>

namespace CalculatorApp {

    using namespace System;
    using namespace System::Globalization;
    using namespace System::Collections::Generic;
    using namespace System::Text;
    using namespace System::Windows::Forms;

    // Команды всех кнопок калькулятора
    public enum class OperationCommand
    {
        Number0 = 0,
        Number1,
        Number2,
        Number3,
        Number4,
        Number5,
        Number6,
        Number7,
        Number8,
        Number9,
        DecimalSeparator,
        ChangeSign,
        Reciprocal,
        Square,
        SquareRoot,
        Multiply,
        Subtract,
        Add,
        Equals,
        Divide,
        Modulo,
        ClearEntry,
        ClearAll,
        Backspace,
        MemoryClear,
        MemoryRecall,
        MemoryAdd,
        MemorySubtract,
        MemoryStore,
        MemoryShow,
        OperationCount
    };

    // Главный класс логики калькулятора
    public ref class Calculator
    {
    private:
        // Допуск для сравнения вещественных чисел с нулем
        literal double ZeroTolerance = 1.0e-12;

        // Поле ввода текущего числа
        TextBox^ txtIn;

        // Метка для вывода текущего выражения
        Label^ lbOut;

        // Левый операнд бинарной операции
        double leftValue;

        // Значение памяти калькулятора
        double memoryValue;

        // Правая часть последнего выражения для повторного нажатия =
        double repeatRightValue;

        // Ожидающая бинарная операция: +, -, *, /, %
        String^ pendingOperation;

        // Последняя операция для повторного нажатия =
        String^ repeatOperation;

        // Есть ли сохраненный левый операнд
        bool hasLeftValue;

        // Нужно ли начинать ввод нового числа
        bool startNewNumber;

        // Было ли последним действием нажатие =
        bool afterEqual;

        // Есть ли последняя операция для повтора =
        bool hasRepeatOperation;

        // Находится ли калькулятор в состоянии ошибки
        bool hasError;

        // Простой журнал вычислений
        List<String^>^ journal;

    private:
        // Получение десятичного разделителя
        String^ getSeparator()
        {
            return CultureInfo::CurrentCulture->NumberFormat->NumberDecimalSeparator;
        }

        // Текст операции для вывода пользователю
        String^ operationToText(String^ operation)
        {
            if (operation->Equals("*"))
            {
                return "x";
            }

            if (operation->Equals("/"))
            {
                return "/";
            }

            if (operation->Equals("%"))
            {
                return "mod";
            }

            return operation;
        }

        // Проверка корректности числового результата
        bool isCorrectNumber(double value)
        {
            return !Double::IsNaN(value) && !Double::IsInfinity(value);
        }

        // Чтение числа из TextBox
        double readValue()
        {
            if (String::IsNullOrEmpty(txtIn->Text))
            {
                return 0.0;
            }

            String^ raw = txtIn->Text->Trim();

            if (String::IsNullOrEmpty(raw))
            {
                return 0.0;
            }

            String^ separator = getSeparator();

            raw = raw->Replace(",", separator);
            raw = raw->Replace(".", separator);

            double value = 0.0;

            if (!Double::TryParse(raw, NumberStyles::Float, CultureInfo::CurrentCulture, value))
            {
                return 0.0;
            }

            return value;
        }

        // Форматирование числа для вывода
        String^ formatNumber(double value)
        {
            if (std::fabs(value) < ZeroTolerance)
            {
                value = 0.0;
            }

            String^ result = value.ToString("G15", CultureInfo::CurrentCulture);

            if (result->Equals("-0"))
            {
                result = "0";
            }

            return result;
        }

        // Запись числа в TextBox
        void writeValue(double value)
        {
            txtIn->Text = formatNumber(value);
        }

        // Перевод калькулятора в состояние ошибки
        void showError(String^ message)
        {
            txtIn->Text = message;
            lbOut->Text = "";

            leftValue = 0.0;
            pendingOperation = nullptr;
            repeatOperation = nullptr;

            hasLeftValue = false;
            hasRepeatOperation = false;
            startNewNumber = true;
            afterEqual = true;
            hasError = true;
        }

        // Полная очистка выражения без очистки памяти
        void clearAll()
        {
            txtIn->Text = "0";
            lbOut->Text = "";

            leftValue = 0.0;
            repeatRightValue = 0.0;

            pendingOperation = nullptr;
            repeatOperation = nullptr;

            hasLeftValue = false;
            hasRepeatOperation = false;
            startNewNumber = true;
            afterEqual = false;
            hasError = false;
        }

        // Очистка только текущего ввода
        void clearEntry()
        {
            if (hasError || afterEqual)
            {
                clearAll();
                return;
            }

            txtIn->Text = "0";
            startNewNumber = true;
        }

        // Добавление записи в журнал
        void addJournalRecord(String^ expression, String^ result)
        {
            String^ line = expression + " " + result;
            journal->Add(line);
        }

        // Выполнение бинарной операции
        bool tryApplyBinaryOperation(double left, double right, String^ operation, double% result)
        {
            result = 0.0;

            if (operation->Equals("+"))
            {
                result = left + right;
            }
            else if (operation->Equals("-"))
            {
                result = left - right;
            }
            else if (operation->Equals("*"))
            {
                result = left * right;
            }
            else if (operation->Equals("/"))
            {
                if (std::fabs(right) < ZeroTolerance)
                {
                    showError("Деление на ноль невозможно");
                    return false;
                }

                result = left / right;
            }
            else if (operation->Equals("%"))
            {
                if (std::fabs(right) < ZeroTolerance)
                {
                    showError("Деление на ноль невозможно");
                    return false;
                }

                result = std::fmod(left, right);
            }

            if (!isCorrectNumber(result))
            {
                showError("Недопустимый результат");
                return false;
            }

            return true;
        }

        // Ввод цифры
        void appendDigit(String^ digit)
        {
            if (hasError || afterEqual)
            {
                clearAll();
            }

            if (startNewNumber)
            {
                if (String::IsNullOrEmpty(pendingOperation))
                {
                    lbOut->Text = "";
                }

                txtIn->Text = "";
                startNewNumber = false;
            }

            if (txtIn->Text->Equals("0"))
            {
                if (!digit->Equals("0"))
                {
                    txtIn->Text = digit;
                }

                return;
            }

            if (txtIn->Text->Equals("-0"))
            {
                txtIn->Text = "-" + digit;
                return;
            }

            txtIn->Text += digit;
        }

        // Ввод десятичного разделителя
        void appendPoint()
        {
            if (hasError || afterEqual)
            {
                clearAll();
            }

            String^ separator = getSeparator();

            if (startNewNumber)
            {
                if (String::IsNullOrEmpty(pendingOperation))
                {
                    lbOut->Text = "";
                }

                txtIn->Text = "0";
                startNewNumber = false;
            }

            if (!txtIn->Text->Contains(separator))
            {
                txtIn->Text += separator;
            }
        }

        // Удаление последнего символа
        void deleteLast()
        {
            if (hasError || afterEqual || startNewNumber)
            {
                return;
            }

            String^ text = txtIn->Text;

            if (text->Length <= 1)
            {
                txtIn->Text = "0";
                startNewNumber = true;
                return;
            }

            if (text->Length == 2 && text->StartsWith("-"))
            {
                txtIn->Text = "0";
                startNewNumber = true;
                return;
            }

            txtIn->Text = text->Substring(0, text->Length - 1);
        }

        // Смена знака числа
        void changeSign()
        {
            if (hasError)
            {
                clearAll();
            }

            if (startNewNumber && !String::IsNullOrEmpty(pendingOperation))
            {
                txtIn->Text = "0";
                startNewNumber = false;
            }

            double value = readValue();

            if (std::fabs(value) < ZeroTolerance)
            {
                return;
            }

            writeValue(-value);

            if (afterEqual)
            {
                lbOut->Text = "";
                afterEqual = false;
            }
        }

        // Выполнение бинарной операции: +, -, *, /, mod
        void executeBinary(String^ operation)
        {
            if (hasError)
            {
                clearAll();
            }

            double currentValue = readValue();

            if (afterEqual)
            {
                leftValue = currentValue;
                pendingOperation = operation;

                hasLeftValue = true;
                startNewNumber = true;
                afterEqual = false;

                lbOut->Text = formatNumber(leftValue) + " " + operationToText(pendingOperation);
                return;
            }

            if (!hasLeftValue || String::IsNullOrEmpty(pendingOperation))
            {
                leftValue = currentValue;
                hasLeftValue = true;
            }
            else
            {
                if (startNewNumber)
                {
                    pendingOperation = operation;
                    lbOut->Text = formatNumber(leftValue) + " " + operationToText(pendingOperation);
                    return;
                }

                double result = 0.0;

                if (!tryApplyBinaryOperation(leftValue, currentValue, pendingOperation, result))
                {
                    return;
                }

                leftValue = result;
                writeValue(result);
            }

            pendingOperation = operation;
            startNewNumber = true;
            hasRepeatOperation = false;

            lbOut->Text = formatNumber(leftValue) + " " + operationToText(pendingOperation);
        }

        // Нажатие =
        void executeEqual()
        {
            if (hasError)
            {
                return;
            }

            double currentValue = readValue();

            if (afterEqual && hasRepeatOperation)
            {
                double result = 0.0;

                String^ expression = formatNumber(currentValue) + " " +
                    operationToText(repeatOperation) + " " +
                    formatNumber(repeatRightValue) + " =";

                if (!tryApplyBinaryOperation(currentValue, repeatRightValue, repeatOperation, result))
                {
                    return;
                }

                lbOut->Text = expression;
                writeValue(result);
                addJournalRecord(expression, formatNumber(result));

                startNewNumber = true;
                afterEqual = true;
                return;
            }

            if (!String::IsNullOrEmpty(pendingOperation) && hasLeftValue)
            {
                double rightValue = currentValue;
                double result = 0.0;

                String^ expression = formatNumber(leftValue) + " " +
                    operationToText(pendingOperation) + " " +
                    formatNumber(rightValue) + " =";

                if (!tryApplyBinaryOperation(leftValue, rightValue, pendingOperation, result))
                {
                    return;
                }

                lbOut->Text = expression;
                writeValue(result);
                addJournalRecord(expression, formatNumber(result));

                repeatOperation = pendingOperation;
                repeatRightValue = rightValue;
                hasRepeatOperation = true;

                leftValue = result;
                pendingOperation = nullptr;
                hasLeftValue = false;

                startNewNumber = true;
                afterEqual = true;
                return;
            }

            lbOut->Text = formatNumber(currentValue) + " =";
            startNewNumber = true;
            afterEqual = true;
        }

        // Выполнение унарной операции
        void executeUnary(String^ operation)
        {
            if (hasError)
            {
                clearAll();
            }

            double value = readValue();
            double result = 0.0;
            String^ expression = "";

            if (operation->Equals("1/x"))
            {
                if (std::fabs(value) < ZeroTolerance)
                {
                    showError("Деление на ноль невозможно");
                    return;
                }

                result = 1.0 / value;
                expression = "1/(" + formatNumber(value) + ")";
            }
            else if (operation->Equals("x2") || operation->Equals("x^2"))
            {
                result = value * value;
                expression = "sqr(" + formatNumber(value) + ")";
            }
            else if (operation->Equals("sqrt"))
            {
                if (value < 0.0)
                {
                    showError("Недопустимый ввод");
                    return;
                }

                result = std::sqrt(value);
                expression = "sqrt(" + formatNumber(value) + ")";
            }

            if (!isCorrectNumber(result))
            {
                showError("Недопустимый результат");
                return;
            }

            if (!String::IsNullOrEmpty(pendingOperation) && hasLeftValue)
            {
                lbOut->Text = formatNumber(leftValue) + " " +
                    operationToText(pendingOperation) + " " +
                    expression;
            }
            else
            {
                lbOut->Text = expression;
            }

            writeValue(result);
            startNewNumber = true;
            afterEqual = false;
        }

        // Очистка памяти
        void memoryClear()
        {
            memoryValue = 0.0;
        }

        // Вызов значения из памяти
        void memoryRead()
        {
            if (hasError || afterEqual)
            {
                clearAll();
            }

            writeValue(memoryValue);
            startNewNumber = true;
            afterEqual = false;
        }

        // Сохранение текущего числа в память
        void memorySave()
        {
            if (hasError)
            {
                return;
            }

            memoryValue = readValue();
        }

        // Добавление текущего числа к памяти
        void memoryPlus()
        {
            if (hasError)
            {
                return;
            }

            memoryValue += readValue();
        }

        // Вычитание текущего числа из памяти
        void memoryMinus()
        {
            if (hasError)
            {
                return;
            }

            memoryValue -= readValue();
        }

        // Просмотр памяти
        void memoryShow()
        {
            MessageBox::Show(
                "Текущее значение памяти: " + formatNumber(memoryValue),
                "Память",
                MessageBoxButtons::OK,
                MessageBoxIcon::Information
            );
        }

    public:
        // Конструктор получает ссылки на элементы формы
        Calculator(TextBox^ inputBox, Label^ outputLabel)
        {
            txtIn = inputBox;
            lbOut = outputLabel;

            memoryValue = 0.0;
            journal = gcnew List<String^>();

            clearAll();
        }

        // Главный метод обработки всех кнопок калькулятора
        void execute(OperationCommand command)
        {
            int commandIndex = safe_cast<int>(command);

            if (commandIndex >= safe_cast<int>(OperationCommand::Number0) &&
                commandIndex <= safe_cast<int>(OperationCommand::Number9))
            {
                appendDigit(Convert::ToString(commandIndex, CultureInfo::InvariantCulture));
                return;
            }

            switch (command)
            {
            case OperationCommand::DecimalSeparator:
                appendPoint();
                break;
            case OperationCommand::ChangeSign:
                changeSign();
                break;
            case OperationCommand::Reciprocal:
                executeUnary("1/x");
                break;
            case OperationCommand::Square:
                executeUnary("x2");
                break;
            case OperationCommand::SquareRoot:
                executeUnary("sqrt");
                break;
            case OperationCommand::Multiply:
                executeBinary("*");
                break;
            case OperationCommand::Subtract:
                executeBinary("-");
                break;
            case OperationCommand::Add:
                executeBinary("+");
                break;
            case OperationCommand::Equals:
                executeEqual();
                break;
            case OperationCommand::Divide:
                executeBinary("/");
                break;
            case OperationCommand::Modulo:
                executeBinary("%");
                break;
            case OperationCommand::ClearEntry:
                clearEntry();
                break;
            case OperationCommand::ClearAll:
                clearAll();
                break;
            case OperationCommand::Backspace:
                deleteLast();
                break;
            case OperationCommand::MemoryClear:
                memoryClear();
                break;
            case OperationCommand::MemoryRecall:
                memoryRead();
                break;
            case OperationCommand::MemoryAdd:
                memoryPlus();
                break;
            case OperationCommand::MemorySubtract:
                memoryMinus();
                break;
            case OperationCommand::MemoryStore:
                memorySave();
                break;
            case OperationCommand::MemoryShow:
                memoryShow();
                break;
            default:
                break;
            }
        }

        // Получение текста журнала
        String^ getJournalText()
        {
            if (journal->Count == 0)
            {
                return "Журнал пуст.";
            }

            StringBuilder^ builder = gcnew StringBuilder();

            for each (String ^ line in journal)
            {
                builder->AppendLine(line);
            }

            return builder->ToString();
        }

        // Очистка журнала
        void clearHistory() {
            journal->Clear();
        }
    };
}
