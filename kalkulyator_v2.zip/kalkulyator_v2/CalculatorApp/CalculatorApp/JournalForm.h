#pragma once
#include "Calculator.h"

namespace CalculatorApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Сводка для JournalForm
	/// </summary>
	public ref class JournalForm : public System::Windows::Forms::Form
	{
	public:
		JournalForm(Calculator^ calculator)
		{
			InitializeComponent();

			this->calculator = calculator;
			refreshJournal();
		}

	private:
		void refreshJournal()
		{
			listExprs->Items->Clear();

			String^ text = calculator->getJournalText();

			array<wchar_t>^ separators = gcnew array<wchar_t>{ L'\r', L'\n' };
			array<String^>^ lines = text->Split(separators, StringSplitOptions::RemoveEmptyEntries);

			for each (String ^ line in lines)
			{
				listExprs->Items->Add(line);
			}
		}

	protected:
		/// <summary>
		/// Освободить все используемые ресурсы
		/// </summary>
		~JournalForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: Calculator^ calculator;
	private: System::Windows::Forms::ListBox^ listExprs;
	private: System::Windows::Forms::Button^ btnClear;
	private: System::Windows::Forms::Button^ btnClose;


	protected:

	protected:

	private:
		/// <summary>
		/// Обязательная переменная конструктора
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода
		/// </summary>
		void InitializeComponent(void)
		{
			this->listExprs = (gcnew System::Windows::Forms::ListBox());
			this->btnClear = (gcnew System::Windows::Forms::Button());
			this->btnClose = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// listExprs
			// 
			this->listExprs->FormattingEnabled = true;
			this->listExprs->Location = System::Drawing::Point(12, 12);
			this->listExprs->Name = L"listExprs";
			this->listExprs->Size = System::Drawing::Size(302, 290);
			this->listExprs->TabIndex = 0;
			// 
			// btnClear
			// 
			this->btnClear->Location = System::Drawing::Point(12, 308);
			this->btnClear->Name = L"btnClear";
			this->btnClear->Size = System::Drawing::Size(131, 40);
			this->btnClear->TabIndex = 1;
			this->btnClear->Text = L"Очистить";
			this->btnClear->UseVisualStyleBackColor = true;
			this->btnClear->Click += gcnew System::EventHandler(this, &JournalForm::btnClear_Click);
			// 
			// btnClose
			// 
			this->btnClose->Location = System::Drawing::Point(183, 308);
			this->btnClose->Name = L"btnClose";
			this->btnClose->Size = System::Drawing::Size(131, 40);
			this->btnClose->TabIndex = 1;
			this->btnClose->Text = L"Закрыть";
			this->btnClose->UseVisualStyleBackColor = true;
			this->btnClose->Click += gcnew System::EventHandler(this, &JournalForm::btnClose_Click);
			// 
			// JournalForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(325, 360);
			this->Controls->Add(this->btnClose);
			this->Controls->Add(this->btnClear);
			this->Controls->Add(this->listExprs);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Name = L"JournalForm";
			this->Text = L"Журнал";
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void btnClear_Click(System::Object^ sender, System::EventArgs^ e) {
		calculator->clearHistory();
		refreshJournal();
	}
	private: System::Void btnClose_Click(System::Object^ sender, System::EventArgs^ e) {
		Close();
	}
	};
}
