#pragma once
#include "Calculator.h"
#include "JournalForm.h"

namespace CalculatorApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Сводка для CalculatorForm
	/// </summary>
	public ref class CalculatorForm : public System::Windows::Forms::Form
	{
	public:
		CalculatorForm(void)
		{
			InitializeComponent();
			// Создаем объект логики калькулятора после создания txtIn и lbOut
			calculator = gcnew Calculator(txtIn, lbOut);
			configureOperationButtons();
		}

	protected:
		/// <summary>
		/// Освободить все используемые ресурсы
		/// </summary>
		~CalculatorForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private:
		Calculator^ calculator;
	private: System::Windows::Forms::TextBox^ txtIn;
	protected:

	protected:



	private: System::Windows::Forms::Button^ btn7;
	private: System::Windows::Forms::Button^ btn8;
	private: System::Windows::Forms::Button^ btn9;
	private: System::Windows::Forms::Button^ btn4;
	private: System::Windows::Forms::Button^ btn5;
	private: System::Windows::Forms::Button^ btn6;
	private: System::Windows::Forms::Button^ btn1;
	private: System::Windows::Forms::Button^ btn2;
	private: System::Windows::Forms::Button^ btn3;
	private: System::Windows::Forms::Button^ btnPMinus;





	private: System::Windows::Forms::Button^ btn0;
	private: System::Windows::Forms::Button^ btnPoint;
	private: System::Windows::Forms::Button^ btnDivX;
	private: System::Windows::Forms::Button^ btnSquare;

	private: System::Windows::Forms::Button^ btnSqrt;
	private: System::Windows::Forms::Button^ btnMult;
	private: System::Windows::Forms::Button^ btnMinus;
	private: System::Windows::Forms::Button^ btnPlus;
	private: System::Windows::Forms::Button^ btnEqual;




	private: System::Windows::Forms::Button^ btnDiv;
	private: System::Windows::Forms::Button^ btnDivv;
	private: System::Windows::Forms::Button^ btnCE;
	private: System::Windows::Forms::Button^ btnC;
	private: System::Windows::Forms::Button^ btnDel;
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ журналToolStripMenuItem;
	private: System::Windows::Forms::Button^ btnMC;
	private: System::Windows::Forms::Button^ btnMR;
	private: System::Windows::Forms::Button^ btnMPlus;
	private: System::Windows::Forms::Button^ btnMMinus;
	private: System::Windows::Forms::Button^ btnMS;
	private: System::Windows::Forms::Button^ btnM;
	private: System::Windows::Forms::Label^ lbOut;

	private:
		void configureOperationButtons()
		{
			cli::array<System::Windows::Forms::Button^>^ buttons =
				gcnew cli::array<System::Windows::Forms::Button^>(
					safe_cast<int>(OperationCommand::OperationCount))
			{
				this->btn0,
				this->btn1,
				this->btn2,
				this->btn3,
				this->btn4,
				this->btn5,
				this->btn6,
				this->btn7,
				this->btn8,
				this->btn9,
				this->btnPoint,
				this->btnPMinus,
				this->btnDivX,
				this->btnSquare,
				this->btnSqrt,
				this->btnMult,
				this->btnMinus,
				this->btnPlus,
				this->btnEqual,
				this->btnDiv,
				this->btnDivv,
				this->btnCE,
				this->btnC,
				this->btnDel,
				this->btnMC,
				this->btnMR,
				this->btnMPlus,
				this->btnMMinus,
				this->btnMS,
				this->btnM
			};

			for (int i = 0; i < safe_cast<int>(OperationCommand::OperationCount); i++)
			{
				buttons[i]->Tag = i;
				buttons[i]->Click += gcnew System::EventHandler(
					this, &CalculatorForm::buttonClick);
			}
		}

		System::Void buttonClick(System::Object^ sender, System::EventArgs^ e)
		{
			System::Windows::Forms::Button^ button =
				safe_cast<System::Windows::Forms::Button^>(sender);
			OperationCommand command = safe_cast<OperationCommand>(
				safe_cast<int>(button->Tag));
			calculator->execute(command);
		}
	protected:

	private:
		/// <summary>
		/// Обязательная переменная конструктора
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtIn = (gcnew System::Windows::Forms::TextBox());
			this->btn7 = (gcnew System::Windows::Forms::Button());
			this->btn8 = (gcnew System::Windows::Forms::Button());
			this->btn9 = (gcnew System::Windows::Forms::Button());
			this->btn4 = (gcnew System::Windows::Forms::Button());
			this->btn5 = (gcnew System::Windows::Forms::Button());
			this->btn6 = (gcnew System::Windows::Forms::Button());
			this->btn1 = (gcnew System::Windows::Forms::Button());
			this->btn2 = (gcnew System::Windows::Forms::Button());
			this->btn3 = (gcnew System::Windows::Forms::Button());
			this->btnPMinus = (gcnew System::Windows::Forms::Button());
			this->btn0 = (gcnew System::Windows::Forms::Button());
			this->btnPoint = (gcnew System::Windows::Forms::Button());
			this->btnDivX = (gcnew System::Windows::Forms::Button());
			this->btnSquare = (gcnew System::Windows::Forms::Button());
			this->btnSqrt = (gcnew System::Windows::Forms::Button());
			this->btnMult = (gcnew System::Windows::Forms::Button());
			this->btnMinus = (gcnew System::Windows::Forms::Button());
			this->btnPlus = (gcnew System::Windows::Forms::Button());
			this->btnEqual = (gcnew System::Windows::Forms::Button());
			this->btnDiv = (gcnew System::Windows::Forms::Button());
			this->btnDivv = (gcnew System::Windows::Forms::Button());
			this->btnCE = (gcnew System::Windows::Forms::Button());
			this->btnC = (gcnew System::Windows::Forms::Button());
			this->btnDel = (gcnew System::Windows::Forms::Button());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->журналToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->btnMC = (gcnew System::Windows::Forms::Button());
			this->btnMR = (gcnew System::Windows::Forms::Button());
			this->btnMPlus = (gcnew System::Windows::Forms::Button());
			this->btnMMinus = (gcnew System::Windows::Forms::Button());
			this->btnMS = (gcnew System::Windows::Forms::Button());
			this->btnM = (gcnew System::Windows::Forms::Button());
			this->lbOut = (gcnew System::Windows::Forms::Label());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// txtIn
			// 
			this->txtIn->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->txtIn->Location = System::Drawing::Point(7, 65);
			this->txtIn->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->txtIn->Name = L"txtIn";
			this->txtIn->ReadOnly = true;
			this->txtIn->Size = System::Drawing::Size(286, 26);
			this->txtIn->TabIndex = 1;
			// 
			// btn7
			// 
			this->btn7->Location = System::Drawing::Point(7, 269);
			this->btn7->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn7->Name = L"btn7";
			this->btn7->Size = System::Drawing::Size(66, 51);
			this->btn7->TabIndex = 2;
			this->btn7->Text = L"7";
			this->btn7->UseVisualStyleBackColor = true;
			// 
			// btn8
			// 
			this->btn8->Location = System::Drawing::Point(80, 269);
			this->btn8->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn8->Name = L"btn8";
			this->btn8->Size = System::Drawing::Size(66, 51);
			this->btn8->TabIndex = 2;
			this->btn8->Text = L"8";
			this->btn8->UseVisualStyleBackColor = true;
			// 
			// btn9
			// 
			this->btn9->Location = System::Drawing::Point(154, 269);
			this->btn9->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn9->Name = L"btn9";
			this->btn9->Size = System::Drawing::Size(66, 51);
			this->btn9->TabIndex = 2;
			this->btn9->Text = L"9";
			this->btn9->UseVisualStyleBackColor = true;
			// 
			// btn4
			// 
			this->btn4->Location = System::Drawing::Point(7, 327);
			this->btn4->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn4->Name = L"btn4";
			this->btn4->Size = System::Drawing::Size(66, 51);
			this->btn4->TabIndex = 2;
			this->btn4->Text = L"4";
			this->btn4->UseVisualStyleBackColor = true;
			// 
			// btn5
			// 
			this->btn5->Location = System::Drawing::Point(80, 327);
			this->btn5->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn5->Name = L"btn5";
			this->btn5->Size = System::Drawing::Size(66, 51);
			this->btn5->TabIndex = 2;
			this->btn5->Text = L"5";
			this->btn5->UseVisualStyleBackColor = true;
			// 
			// btn6
			// 
			this->btn6->Location = System::Drawing::Point(154, 327);
			this->btn6->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn6->Name = L"btn6";
			this->btn6->Size = System::Drawing::Size(66, 51);
			this->btn6->TabIndex = 2;
			this->btn6->Text = L"6";
			this->btn6->UseVisualStyleBackColor = true;
			// 
			// btn1
			// 
			this->btn1->Location = System::Drawing::Point(7, 385);
			this->btn1->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn1->Name = L"btn1";
			this->btn1->Size = System::Drawing::Size(66, 51);
			this->btn1->TabIndex = 2;
			this->btn1->Text = L"1";
			this->btn1->UseVisualStyleBackColor = true;
			// 
			// btn2
			// 
			this->btn2->Location = System::Drawing::Point(80, 385);
			this->btn2->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn2->Name = L"btn2";
			this->btn2->Size = System::Drawing::Size(66, 51);
			this->btn2->TabIndex = 2;
			this->btn2->Text = L"2";
			this->btn2->UseVisualStyleBackColor = true;
			// 
			// btn3
			// 
			this->btn3->Location = System::Drawing::Point(154, 385);
			this->btn3->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn3->Name = L"btn3";
			this->btn3->Size = System::Drawing::Size(66, 51);
			this->btn3->TabIndex = 2;
			this->btn3->Text = L"3";
			this->btn3->UseVisualStyleBackColor = true;
			// 
			// btnPMinus
			// 
			this->btnPMinus->Location = System::Drawing::Point(7, 442);
			this->btnPMinus->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnPMinus->Name = L"btnPMinus";
			this->btnPMinus->Size = System::Drawing::Size(66, 51);
			this->btnPMinus->TabIndex = 2;
			this->btnPMinus->Text = L"+/-";
			this->btnPMinus->UseVisualStyleBackColor = true;
			// 
			// btn0
			// 
			this->btn0->Location = System::Drawing::Point(80, 442);
			this->btn0->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn0->Name = L"btn0";
			this->btn0->Size = System::Drawing::Size(66, 51);
			this->btn0->TabIndex = 2;
			this->btn0->Text = L"0";
			this->btn0->UseVisualStyleBackColor = true;
			// 
			// btnPoint
			// 
			this->btnPoint->Location = System::Drawing::Point(154, 442);
			this->btnPoint->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnPoint->Name = L"btnPoint";
			this->btnPoint->Size = System::Drawing::Size(66, 51);
			this->btnPoint->TabIndex = 2;
			this->btnPoint->Text = L",";
			this->btnPoint->UseVisualStyleBackColor = true;
			// 
			// btnDivX
			// 
			this->btnDivX->Location = System::Drawing::Point(7, 212);
			this->btnDivX->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnDivX->Name = L"btnDivX";
			this->btnDivX->Size = System::Drawing::Size(66, 51);
			this->btnDivX->TabIndex = 2;
			this->btnDivX->Text = L"1/x";
			this->btnDivX->UseVisualStyleBackColor = true;
			// 
			// btnSquare
			// 
			this->btnSquare->Location = System::Drawing::Point(80, 212);
			this->btnSquare->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnSquare->Name = L"btnSquare";
			this->btnSquare->Size = System::Drawing::Size(66, 51);
			this->btnSquare->TabIndex = 2;
			this->btnSquare->Text = L"x^2";
			this->btnSquare->UseVisualStyleBackColor = true;
			// 
			// btnSqrt
			// 
			this->btnSqrt->Location = System::Drawing::Point(154, 212);
			this->btnSqrt->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnSqrt->Name = L"btnSqrt";
			this->btnSqrt->Size = System::Drawing::Size(66, 51);
			this->btnSqrt->TabIndex = 2;
			this->btnSqrt->Text = L"sqrt(x)";
			this->btnSqrt->UseVisualStyleBackColor = true;
			// 
			// btnMult
			// 
			this->btnMult->Location = System::Drawing::Point(227, 269);
			this->btnMult->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMult->Name = L"btnMult";
			this->btnMult->Size = System::Drawing::Size(66, 51);
			this->btnMult->TabIndex = 2;
			this->btnMult->Text = L"x";
			this->btnMult->UseVisualStyleBackColor = true;
			// 
			// btnMinus
			// 
			this->btnMinus->Location = System::Drawing::Point(227, 327);
			this->btnMinus->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMinus->Name = L"btnMinus";
			this->btnMinus->Size = System::Drawing::Size(66, 51);
			this->btnMinus->TabIndex = 2;
			this->btnMinus->Text = L"-";
			this->btnMinus->UseVisualStyleBackColor = true;
			// 
			// btnPlus
			// 
			this->btnPlus->Location = System::Drawing::Point(227, 385);
			this->btnPlus->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnPlus->Name = L"btnPlus";
			this->btnPlus->Size = System::Drawing::Size(66, 51);
			this->btnPlus->TabIndex = 2;
			this->btnPlus->Text = L"+";
			this->btnPlus->UseVisualStyleBackColor = true;
			// 
			// btnEqual
			// 
			this->btnEqual->Location = System::Drawing::Point(227, 442);
			this->btnEqual->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnEqual->Name = L"btnEqual";
			this->btnEqual->Size = System::Drawing::Size(66, 51);
			this->btnEqual->TabIndex = 2;
			this->btnEqual->Text = L"=";
			this->btnEqual->UseVisualStyleBackColor = true;
			// 
			// btnDiv
			// 
			this->btnDiv->Location = System::Drawing::Point(227, 212);
			this->btnDiv->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnDiv->Name = L"btnDiv";
			this->btnDiv->Size = System::Drawing::Size(66, 51);
			this->btnDiv->TabIndex = 2;
			this->btnDiv->Text = L"/";
			this->btnDiv->UseVisualStyleBackColor = true;
			// 
			// btnDivv
			// 
			this->btnDivv->Location = System::Drawing::Point(7, 154);
			this->btnDivv->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnDivv->Name = L"btnDivv";
			this->btnDivv->Size = System::Drawing::Size(66, 51);
			this->btnDivv->TabIndex = 2;
			this->btnDivv->Text = L"%";
			this->btnDivv->UseVisualStyleBackColor = true;
			// 
			// btnCE
			// 
			this->btnCE->Location = System::Drawing::Point(80, 154);
			this->btnCE->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnCE->Name = L"btnCE";
			this->btnCE->Size = System::Drawing::Size(66, 51);
			this->btnCE->TabIndex = 2;
			this->btnCE->Text = L"CE";
			this->btnCE->UseVisualStyleBackColor = true;
			// 
			// btnC
			// 
			this->btnC->Location = System::Drawing::Point(154, 154);
			this->btnC->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnC->Name = L"btnC";
			this->btnC->Size = System::Drawing::Size(66, 51);
			this->btnC->TabIndex = 2;
			this->btnC->Text = L"C";
			this->btnC->UseVisualStyleBackColor = true;
			// 
			// btnDel
			// 
			this->btnDel->Location = System::Drawing::Point(227, 154);
			this->btnDel->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnDel->Name = L"btnDel";
			this->btnDel->Size = System::Drawing::Size(66, 51);
			this->btnDel->TabIndex = 2;
			this->btnDel->Text = L"DEL";
			this->btnDel->UseVisualStyleBackColor = true;
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->журналToolStripMenuItem });
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Padding = System::Windows::Forms::Padding(7, 2, 0, 2);
			this->menuStrip1->Size = System::Drawing::Size(304, 24);
			this->menuStrip1->TabIndex = 3;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// журналToolStripMenuItem
			// 
			this->журналToolStripMenuItem->Name = L"журналToolStripMenuItem";
			this->журналToolStripMenuItem->Size = System::Drawing::Size(63, 20);
			this->журналToolStripMenuItem->Text = L"Журнал";
			this->журналToolStripMenuItem->Click += gcnew System::EventHandler(this, &CalculatorForm::журналToolStripMenuItem_Click);
			// 
			// btnMC
			// 
			this->btnMC->Location = System::Drawing::Point(7, 97);
			this->btnMC->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMC->Name = L"btnMC";
			this->btnMC->Size = System::Drawing::Size(43, 51);
			this->btnMC->TabIndex = 2;
			this->btnMC->Text = L"MC";
			this->btnMC->UseVisualStyleBackColor = true;
			// 
			// btnMR
			// 
			this->btnMR->Location = System::Drawing::Point(58, 97);
			this->btnMR->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMR->Name = L"btnMR";
			this->btnMR->Size = System::Drawing::Size(48, 51);
			this->btnMR->TabIndex = 2;
			this->btnMR->Text = L"MR";
			this->btnMR->UseVisualStyleBackColor = true;
			// 
			// btnMPlus
			// 
			this->btnMPlus->Location = System::Drawing::Point(112, 97);
			this->btnMPlus->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMPlus->Name = L"btnMPlus";
			this->btnMPlus->Size = System::Drawing::Size(46, 51);
			this->btnMPlus->TabIndex = 2;
			this->btnMPlus->Text = L"M+";
			this->btnMPlus->UseVisualStyleBackColor = true;
			// 
			// btnMMinus
			// 
			this->btnMMinus->Location = System::Drawing::Point(165, 97);
			this->btnMMinus->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMMinus->Name = L"btnMMinus";
			this->btnMMinus->Size = System::Drawing::Size(40, 51);
			this->btnMMinus->TabIndex = 2;
			this->btnMMinus->Text = L"M-";
			this->btnMMinus->UseVisualStyleBackColor = true;
			// 
			// btnMS
			// 
			this->btnMS->Location = System::Drawing::Point(212, 97);
			this->btnMS->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnMS->Name = L"btnMS";
			this->btnMS->Size = System::Drawing::Size(46, 51);
			this->btnMS->TabIndex = 2;
			this->btnMS->Text = L"MS";
			this->btnMS->UseVisualStyleBackColor = true;
			// 
			// btnM
			// 
			this->btnM->Location = System::Drawing::Point(262, 97);
			this->btnM->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btnM->Name = L"btnM";
			this->btnM->Size = System::Drawing::Size(31, 51);
			this->btnM->TabIndex = 2;
			this->btnM->Text = L"M";
			this->btnM->UseVisualStyleBackColor = true;
			// 
			// lbOut
			// 
			this->lbOut->AutoSize = true;
			this->lbOut->Location = System::Drawing::Point(12, 47);
			this->lbOut->Name = L"lbOut";
			this->lbOut->Size = System::Drawing::Size(16, 15);
			this->lbOut->TabIndex = 4;
			this->lbOut->Text = L"...";
			// 
			// CalculatorForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(7, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(304, 503);
			this->Controls->Add(this->lbOut);
			this->Controls->Add(this->btnM);
			this->Controls->Add(this->btnMS);
			this->Controls->Add(this->btnMMinus);
			this->Controls->Add(this->btnDel);
			this->Controls->Add(this->btnDiv);
			this->Controls->Add(this->btnMPlus);
			this->Controls->Add(this->btnC);
			this->Controls->Add(this->btnSqrt);
			this->Controls->Add(this->btnEqual);
			this->Controls->Add(this->btnMR);
			this->Controls->Add(this->btnCE);
			this->Controls->Add(this->btnSquare);
			this->Controls->Add(this->btnPoint);
			this->Controls->Add(this->btnPlus);
			this->Controls->Add(this->btn0);
			this->Controls->Add(this->btn3);
			this->Controls->Add(this->btn2);
			this->Controls->Add(this->btnMinus);
			this->Controls->Add(this->btnMC);
			this->Controls->Add(this->btnDivv);
			this->Controls->Add(this->btnDivX);
			this->Controls->Add(this->btn6);
			this->Controls->Add(this->btnPMinus);
			this->Controls->Add(this->btn5);
			this->Controls->Add(this->btnMult);
			this->Controls->Add(this->btn1);
			this->Controls->Add(this->btn9);
			this->Controls->Add(this->btn4);
			this->Controls->Add(this->btn8);
			this->Controls->Add(this->btn7);
			this->Controls->Add(this->txtIn);
			this->Controls->Add(this->menuStrip1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->Name = L"CalculatorForm";
			this->Text = L"Калькулятор";
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void журналToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		// Открытие журнала
		JournalForm^ journalForm = gcnew JournalForm(calculator);
		journalForm->Show();
	}
	};
}
